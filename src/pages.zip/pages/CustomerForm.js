import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { customerApi } from '../services/api';
import FormField from '../components/FormField';
import LoadingSpinner from '../components/LoadingSpinner';

function CustomerForm() {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    phone_number: ''
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState('');

  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  useEffect(() => {
    if (isEdit) {
      fetchCustomer();
    }
  }, [id, isEdit]);

  const fetchCustomer = async () => {
    try {
      setLoading(true);
      const response = await customerApi.getById(id);
      setFormData({
        first_name: response.data.data.first_name,
        last_name: response.data.data.last_name,
        phone_number: response.data.data.phone_number
      });
    } catch (err) {
      setSubmitError('Failed to fetch customer details');
    } finally {
      setLoading(false); // ✅ Fixed: Always runs
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.first_name.trim()) {
      newErrors.first_name = 'First name is required';
    }

    if (!formData.last_name.trim()) {
      newErrors.last_name = 'Last name is required';
    }

    if (!formData.phone_number.trim()) {
      newErrors.phone_number = 'Phone number is required';
    } else if (!/^[0-9]{10}$/.test(formData.phone_number)) {
      newErrors.phone_number = 'Phone number must be 10 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      setSubmitError('');

      if (isEdit) {
        await customerApi.update(id, formData);
      } else {
        await customerApi.create(formData);
      }

      navigate('/customers');
    } catch (err) {
      if (err.response?.data?.error) {
        setSubmitError(err.response.data.error);
      } else {
        setSubmitError('Failed to save customer');
      }
    } finally {
      setLoading(false); // ✅ Fixed: Always runs
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  if (loading && isEdit) return <LoadingSpinner />;

  return (
    <div className="customer-form">
      <div className="page-header">
        <h1>{isEdit ? 'Edit Customer' : 'Add New Customer'}</h1>
      </div>

      <div className="form-container">
        <form onSubmit={handleSubmit}>
          {submitError && (
            <div className="alert alert-error">{submitError}</div>
          )}

          <FormField
            label="First Name"
            name="first_name"
            value={formData.first_name}
            onChange={handleChange}
            error={errors.first_name}
            required
          />

          <FormField
            label="Last Name"
            name="last_name"
            value={formData.last_name}
            onChange={handleChange}
            error={errors.last_name}
            required
          />

          <FormField
            label="Phone Number"
            name="phone_number"
            type="tel"
            value={formData.phone_number}
            onChange={handleChange}
            error={errors.phone_number}
            placeholder="10-digit phone number"
            required
          />

          <div className="form-actions">
            <button
              type="button"
              onClick={() => navigate('/customers')}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary"
            >
              {loading ? 'Saving...' : isEdit ? 'Update Customer' : 'Create Customer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default CustomerForm;
